------------------
Freebie: Nice Things Icon Set (128 Icons, PNG, AI)
Designed by Chris Behr (http://www.chrisbehr.com/) and released for Smashing Magazine and its readers.
------------------

Dear Friends,

Thank you for downloading this icon set!

This freebie has been brought to you by SmashingMagazine.com. You can freely use it for both your private and commercial projects, including software, online services, templates and themes. 

However, the icons may not be resold, sublicensed, rented, transferred or otherwise made available for use. The icons may not be offered for free downloading from websites other than SmashingMagazine.com.

Please link to the article in which this freebie was released if you would like to spread the word: http://www.smashingmagazine.com/2013/11/01/freebie-nice-things-icon-set/

Smashing Magazine Team,
www.smashingmagazine.com

